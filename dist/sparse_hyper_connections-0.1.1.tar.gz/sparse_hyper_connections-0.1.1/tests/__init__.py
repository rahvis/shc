"""
SHC Test Suite

Comprehensive tests for the Sparse Selective Hyper-Connections package.
"""
