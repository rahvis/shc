"""
SHC Scripts Module

Command-line scripts for training, evaluation, and inference.
"""
