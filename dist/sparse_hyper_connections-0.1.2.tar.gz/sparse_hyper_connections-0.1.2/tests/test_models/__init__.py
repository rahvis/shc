"""Test suite for SHC models."""
